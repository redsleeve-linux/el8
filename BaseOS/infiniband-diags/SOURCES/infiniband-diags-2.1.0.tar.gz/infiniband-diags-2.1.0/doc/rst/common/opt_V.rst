.. Define the common option -V

**-V, --version**     show the version info.

