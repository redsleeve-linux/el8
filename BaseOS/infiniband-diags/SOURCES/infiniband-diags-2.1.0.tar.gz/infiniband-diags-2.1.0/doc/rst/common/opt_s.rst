.. Define the common option -s

**-s, --sm_port <smlid>**     use 'smlid' as the target lid for SA queries.

